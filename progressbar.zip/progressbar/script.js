// This is only here for illustration purposes. See comments below for how to create new start/end points
const randomStart = Math.random() * 24;
const randomEnd = Math.random() * 24;

function timeElapsed() {
  const now = new Date();
  const nowEpoch = now.getTime() / (1000 * 3600);

  // This is only here for illustration purposes. See comments below for how to create new start/end points
  const start = nowEpoch - randomStart;
  const end = nowEpoch + randomEnd;

  // This is how you would define non-random, user determined start/end points
  // var start = new Date(2013,08,04).getTime() / (1000 * 3600);
  // var end = new Date(2013,08,10).getTime() / (1000 * 3600);

  const total = roundDown(end - start);
  const elapsed = roundDown(nowEpoch - start);
  const progress = roundDown(elapsed / total);

  document.getElementById('current').innerHTML = showDate(now);
  document.getElementById('total').innerHTML = `${total} hours`;
  document.getElementById('elapsed').innerHTML = `${elapsed} hours`;
  document.getElementById('progress').innerHTML = `${progress} %`;
  document.getElementById('p').value = progress * 100;
}

function roundDown(floating) {
  const rounded = Math.round(floating * 100) / 100;
  return rounded;
}

function showDate(x) {
  const year = x.getFullYear();
  const month = x.getMonth() >= 9 ? x.getMonth() + 1 : `0${x.getMonth() + 1}`;
  const day = x.getDate() >= 9 ? x.getDate() : `0${x.getDate()}`;
  const hour = x.getHours() >= 9 ? x.getHours() : `0${x.getHours()}`;
  const minutes = x.getMinutes() >= 9 ? x.getMinutes() : `0${x.getMinutes()}`;
  const seconds = x.getSeconds() >= 9 ? x.getSeconds() : `0${x.getSeconds()}`;
  const string = `${year}-${month}-${day} ${hour}:${minutes}:${seconds}`;
  return string;
}

window.onload = timeElapsed;
window.setInterval(timeElapsed, 1000);
